
package indicemasacorporal;

public class IndiceMAsaCorporal {

    public static void main(String[] args) {
        double peso ,estatura, indice;
        
        System.out.println("Ingrese por favor su peso en kg: ");
        
    }
    
}
