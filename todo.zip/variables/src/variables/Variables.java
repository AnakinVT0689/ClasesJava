
package variables;


public class Variables {
    public static void main(String[] args) {
           
        int num1, num2, resultado;
        num1 = 4 ;
        num2 = 2;
        
        resultado = num1 / num2;
        System.out.println("El resultado de la division es de: " + resultado);
    }
    
}
